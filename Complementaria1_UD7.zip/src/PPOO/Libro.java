package PPOO;

public class Libro { /* Decalro los atributos que se va utilizar en la clase libro */
	private String titulo;
	private String autor;
	private int numPaginas;
	private boolean disponible;

	public Libro(String titulo, String autor, int numPaginas) { /*
																 * Utilizo este metodo para aclarar los atributos, es
																 * decir a quer hacen referencia cada uno de ellos.
																 */
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.disponible = true;
	}

	public void prestar() { /* Creo este metodo para poder prestar un libro */
		if (disponible) {
			System.out.println("El libro ha sido prestado."); /* Si esta disponible se prestará el libro */
			disponible = false;
		} else {
			System.out.println("El libro no está disponible en este momento.");/*
																				 * Si no está disponible pues imprimirá
																				 * que no está disponible
																				 */
		}
	}

	public void devolver() { /* Creo este metodo que servirá para devolver el libro */
		if (!disponible) {
			System.out.println(
					"El libro ha sido devuelto. Gracias."); /* Si no está disponible se imprimirá que se ha devuelto */
			disponible = true;
		} else {
			System.out.println("Este libro no necesita ser devuelto en este momento."); /*
																						 * Y si está disponilbe se
																						 * imprimirá que el libro no
																						 * hace falta devolverlo todavía
																						 */
		}
	}

	public String toString() { /*
								 * Utilizo este metodo que me sirve para imprimir toda la información acerca de
								 * los libros
								 */
		return "Libro{" + "titulo='" + titulo + '\'' + ", autor='" + autor + '\'' + ", numPaginas=" + numPaginas
				+ ", disponible=" + disponible + '}';
	}

	public static void main(String[] args) {
		Libro libro1 = new Libro("La vida de PI", "Yann Martel", 335);
		Libro libro2 = new Libro("Planeta 51", "Joe Stillman", 112);

		System.out.println("Información del libro 1:");
		System.out.println(libro1.toString());
		libro1.prestar();
		libro1.devolver();

		System.out.println("\nInformación del libro 2:");
		System.out.println(libro2.toString());
		libro2.prestar();
		libro2.prestar();
	}
}